// Pruebas para el procesamiento de comandos del TP.
// Permite verificar que comandos como agregar_archivo, info_vuelo, etc., funcionen correctamente.
package comandos_test

import (
	"testing"

	"tp2/comandos"
)

func TestAgregarArchivo(t *testing.T) {
	// Inicializar estructuras
	comandos.InicializarEstructuras()

}
